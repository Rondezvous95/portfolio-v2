/**
 * Design: Warm Professional - Human-Centered Minimalism
 * Testimonials with large quote marks, card layout, and LinkedIn recommendations
 */
import { testimonials } from "@/lib/portfolio-data";
import { motion } from "framer-motion";
import { useInView } from "@/hooks/useInView";
import { Quote, Linkedin } from "lucide-react";

const typeLabels: Record<string, string> = {
  internal: "Internal Recognition",
  client: "Client Feedback",
  peer: "Peer Endorsement",
  linkedin: "LinkedIn Recommendation",
};

const typeColors: Record<string, string> = {
  internal: "bg-amber-50 text-amber-700 border-amber-200",
  client: "bg-primary/10 text-primary border-primary/20",
  peer: "bg-blue-50 text-blue-700 border-blue-200",
  linkedin: "bg-sky-50 text-sky-700 border-sky-200",
};

export default function TestimonialsSection() {
  const { ref, inView } = useInView({ threshold: 0.1 });

  // Separate LinkedIn recommendations (featured) from other testimonials
  const linkedinRecs = testimonials.filter((t) => t.type === "linkedin");
  const otherRecs = testimonials.filter((t) => t.type !== "linkedin");

  return (
    <section id="testimonials" className="py-20 lg:py-28" ref={ref}>
      <div className="container">
        {/* Section header */}
        <motion.div
          className="text-center max-w-2xl mx-auto mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <span className="text-sm font-medium text-primary uppercase tracking-wider">
            Recognition
          </span>
          <h2 className="font-heading font-bold text-3xl sm:text-4xl lg:text-5xl text-foreground mt-3">
            What People Say
          </h2>
        </motion.div>

        {/* LinkedIn Recommendations - Featured */}
        {linkedinRecs.length > 0 && (
          <div className="mb-10">
            <motion.div
              className="flex items-center gap-2 mb-6"
              initial={{ opacity: 0, y: 10 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.1, duration: 0.5 }}
            >
              <Linkedin className="text-sky-600" size={20} />
              <h3 className="font-heading font-semibold text-lg text-foreground">
                LinkedIn Recommendations
              </h3>
            </motion.div>
            <div className="grid md:grid-cols-2 gap-6 lg:gap-8">
              {linkedinRecs.map((testimonial, i) => (
                <motion.div
                  key={testimonial.id}
                  className="bg-card rounded-2xl p-6 lg:p-8 border border-border shadow-sm hover:shadow-md transition-shadow relative"
                  initial={{ opacity: 0, y: 30 }}
                  animate={inView ? { opacity: 1, y: 0 } : {}}
                  transition={{ delay: 0.15 + i * 0.1, duration: 0.5 }}
                >
                  {/* Quote icon */}
                  <Quote className="text-sky-200 mb-4" size={36} />

                  {/* Type badge */}
                  <span
                    className={`inline-block px-2.5 py-0.5 text-xs font-medium rounded-full border mb-4 ${
                      typeColors[testimonial.type]
                    }`}
                  >
                    {typeLabels[testimonial.type]}
                  </span>

                  {/* Quote text */}
                  <p className="text-muted-foreground text-sm leading-relaxed mb-6 italic">
                    "{testimonial.quote}"
                  </p>

                  {/* Author */}
                  <div className="border-t border-border pt-4">
                    <p className="font-heading font-semibold text-sm text-foreground">
                      {testimonial.author}
                    </p>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {testimonial.role}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {/* Other testimonials */}
        <div className="grid md:grid-cols-3 gap-6 lg:gap-8">
          {otherRecs.map((testimonial, i) => (
            <motion.div
              key={testimonial.id}
              className="bg-card rounded-2xl p-6 lg:p-8 border border-border shadow-sm hover:shadow-md transition-shadow relative"
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.3 + i * 0.1, duration: 0.5 }}
            >
              {/* Quote icon */}
              <Quote className="text-primary/20 mb-4" size={36} />

              {/* Type badge */}
              <span
                className={`inline-block px-2.5 py-0.5 text-xs font-medium rounded-full border mb-4 ${
                  typeColors[testimonial.type]
                }`}
              >
                {typeLabels[testimonial.type]}
              </span>

              {/* Quote text */}
              <p className="text-muted-foreground text-sm leading-relaxed mb-6 italic">
                "{testimonial.quote}"
              </p>

              {/* Author */}
              <div className="border-t border-border pt-4">
                <p className="font-heading font-semibold text-sm text-foreground">
                  {testimonial.author}
                </p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {testimonial.role}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
