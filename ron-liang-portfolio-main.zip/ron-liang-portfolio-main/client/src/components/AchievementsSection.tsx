/**
 * Design: Warm Professional - Human-Centered Minimalism
 * Signature achievements with large metrics, cards, and images
 */
import { achievements } from "@/lib/portfolio-data";
import { motion } from "framer-motion";
import { useInView } from "@/hooks/useInView";
import { Award } from "lucide-react";

export default function AchievementsSection() {
  const { ref, inView } = useInView({ threshold: 0.1 });

  return (
    <section id="achievements" className="py-20 lg:py-28 bg-muted/30" ref={ref}>
      <div className="container">
        {/* Section header */}
        <motion.div
          className="text-center max-w-2xl mx-auto mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <span className="text-sm font-medium text-primary uppercase tracking-wider">
            Impact
          </span>
          <h2 className="font-heading font-bold text-3xl sm:text-4xl lg:text-5xl text-foreground mt-3">
            Signature Achievements
          </h2>
        </motion.div>

        {/* Achievement cards */}
        <div className="space-y-12 lg:space-y-16">
          {achievements.map((achievement, i) => (
            <motion.div
              key={achievement.id}
              className={`grid lg:grid-cols-2 gap-8 lg:gap-12 items-center ${
                i % 2 === 1 ? "lg:direction-rtl" : ""
              }`}
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: i * 0.15, duration: 0.6 }}
            >
              {/* Image */}
              <div className={`${i % 2 === 1 ? "lg:order-2" : ""}`}>
                <div className="rounded-2xl overflow-hidden shadow-lg aspect-video">
                  <img
                    src={achievement.image}
                    alt={achievement.title}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                  />
                </div>
              </div>

              {/* Content */}
              <div className={`space-y-4 ${i % 2 === 1 ? "lg:order-1" : ""}`}>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <Award className="text-primary" size={20} />
                  </div>
                  <span className="text-sm font-medium text-primary">
                    {achievement.subtitle}
                  </span>
                </div>

                <h3 className="font-heading font-bold text-2xl lg:text-3xl text-foreground">
                  {achievement.title}
                </h3>

                <p className="text-muted-foreground text-base leading-relaxed">
                  {achievement.description}
                </p>

                {/* Metric highlight */}
                <div className="flex items-baseline gap-2 pt-2">
                  <span className="font-heading font-bold text-4xl lg:text-5xl text-primary">
                    {achievement.metric}
                  </span>
                  <span className="text-sm text-muted-foreground font-medium">
                    {achievement.metricLabel}
                  </span>
                </div>

                {/* Detail pills */}
                <div className="flex flex-wrap gap-2 pt-2">
                  {achievement.details.map((detail) => (
                    <span
                      key={detail}
                      className="px-3 py-1 text-xs font-medium rounded-full bg-card border border-border text-muted-foreground"
                    >
                      {detail}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
