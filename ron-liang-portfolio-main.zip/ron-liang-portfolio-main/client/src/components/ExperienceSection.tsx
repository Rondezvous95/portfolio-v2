/**
 * Design: Warm Professional - Human-Centered Minimalism
 * Detailed experience section with expandable role cards
 */
import { experienceDetails } from "@/lib/portfolio-data";
import { motion } from "framer-motion";
import { useInView } from "@/hooks/useInView";
import { useState } from "react";
import { Briefcase, ChevronDown, ChevronUp, MapPin, TrendingUp } from "lucide-react";

export default function ExperienceSection() {
  const { ref, inView } = useInView({ threshold: 0.1 });
  const [expandedId, setExpandedId] = useState<number | null>(1);

  return (
    <section id="experience" className="py-20 lg:py-28" ref={ref}>
      <div className="container">
        {/* Section header */}
        <motion.div
          className="max-w-2xl mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <span className="text-sm font-medium text-primary uppercase tracking-wider">
            Experience
          </span>
          <h2 className="font-heading font-bold text-3xl sm:text-4xl lg:text-5xl text-foreground mt-3">
            Professional Details
          </h2>
          <p className="text-muted-foreground text-base mt-4">
            Click on each role to see detailed responsibilities and key accomplishments.
          </p>
        </motion.div>

        {/* Experience cards */}
        <div className="space-y-4">
          {experienceDetails.map((exp, i) => (
            <motion.div
              key={exp.id}
              className="bg-card rounded-xl border border-border shadow-sm overflow-hidden hover:shadow-md transition-shadow"
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: i * 0.1, duration: 0.5 }}
            >
              {/* Header - always visible */}
              <button
                className="w-full text-left p-5 lg:p-6 flex items-start gap-4"
                onClick={() => setExpandedId(expandedId === exp.id ? null : exp.id)}
              >
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                  <Briefcase className="text-primary" size={18} />
                </div>

                <div className="flex-1">
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <h3 className="font-heading font-bold text-lg text-foreground">
                      {exp.role}
                    </h3>
                    {exp.promoted && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 text-xs font-medium rounded-full bg-green-50 text-green-700 border border-green-200">
                        <TrendingUp size={12} />
                        Promoted
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground flex flex-wrap items-center gap-2">
                    <span className="font-medium">{exp.company}</span>
                    <span className="text-border">|</span>
                    <span>{exp.period}</span>
                  </p>
                  <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                    <MapPin size={12} />
                    {exp.location}
                  </p>
                </div>

                <div className="shrink-0 text-muted-foreground">
                  {expandedId === exp.id ? (
                    <ChevronUp size={20} />
                  ) : (
                    <ChevronDown size={20} />
                  )}
                </div>
              </button>

              {/* Expanded content */}
              {expandedId === exp.id && (
                <motion.div
                  className="px-5 lg:px-6 pb-5 lg:pb-6 pl-[4.5rem] lg:pl-[5rem]"
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  transition={{ duration: 0.3 }}
                >
                  <ul className="space-y-2.5">
                    {exp.highlights.map((highlight, idx) => (
                      <li
                        key={idx}
                        className="text-sm text-muted-foreground leading-relaxed flex items-start gap-2"
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-primary mt-2 shrink-0" />
                        {highlight}
                      </li>
                    ))}
                  </ul>
                </motion.div>
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
