/**
 * Design: Warm Professional - Human-Centered Minimalism
 * Contact section with email, phone, LinkedIn, and a closing quote
 */
import { personalInfo } from "@/lib/portfolio-data";
import { motion } from "framer-motion";
import { useInView } from "@/hooks/useInView";
import { Mail, Phone, Linkedin, MapPin, ArrowUpRight } from "lucide-react";

export default function ContactSection() {
  const { ref, inView } = useInView({ threshold: 0.2 });

  return (
    <section id="contact" className="py-20 lg:py-28 bg-foreground text-background" ref={ref}>
      <div className="container">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16">
          {/* Left - CTA */}
          <motion.div
            className="space-y-6"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            <span className="text-sm font-medium text-primary uppercase tracking-wider">
              Let's Connect
            </span>
            <h2 className="font-heading font-bold text-3xl sm:text-4xl lg:text-5xl leading-tight">
              Thank you for viewing my portfolio
            </h2>
            <p className="text-background/70 text-lg leading-relaxed max-w-md">
              I'm always open to discussing new opportunities in Learning & Development, training, and enablement.
            </p>
            <blockquote className="border-l-4 border-primary/60 pl-4 italic text-background/80 text-base">
              "{personalInfo.tagline}"
            </blockquote>
          </motion.div>

          {/* Right - Contact details */}
          <motion.div
            className="space-y-6"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.2, duration: 0.6 }}
          >
            <div className="space-y-4">
              {/* Email */}
              <a
                href={`mailto:${personalInfo.email}`}
                className="flex items-center gap-4 p-4 rounded-xl bg-background/5 border border-background/10 hover:bg-background/10 transition-colors group"
              >
                <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                  <Mail className="text-primary" size={18} />
                </div>
                <div className="flex-1">
                  <p className="text-xs text-background/50 uppercase tracking-wider">Email</p>
                  <p className="text-background font-medium">{personalInfo.email}</p>
                </div>
                <ArrowUpRight className="text-background/30 group-hover:text-primary transition-colors" size={18} />
              </a>

              {/* Phone */}
              <a
                href={`tel:${personalInfo.phone}`}
                className="flex items-center gap-4 p-4 rounded-xl bg-background/5 border border-background/10 hover:bg-background/10 transition-colors group"
              >
                <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                  <Phone className="text-primary" size={18} />
                </div>
                <div className="flex-1">
                  <p className="text-xs text-background/50 uppercase tracking-wider">Phone</p>
                  <p className="text-background font-medium">{personalInfo.phone}</p>
                </div>
                <ArrowUpRight className="text-background/30 group-hover:text-primary transition-colors" size={18} />
              </a>

              {/* LinkedIn */}
              <a
                href={personalInfo.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-4 p-4 rounded-xl bg-background/5 border border-background/10 hover:bg-background/10 transition-colors group"
              >
                <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                  <Linkedin className="text-primary" size={18} />
                </div>
                <div className="flex-1">
                  <p className="text-xs text-background/50 uppercase tracking-wider">LinkedIn</p>
                  <p className="text-background font-medium">linkedin.com/in/ronliang</p>
                </div>
                <ArrowUpRight className="text-background/30 group-hover:text-primary transition-colors" size={18} />
              </a>

              {/* Location */}
              <div className="flex items-center gap-4 p-4 rounded-xl bg-background/5 border border-background/10">
                <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                  <MapPin className="text-primary" size={18} />
                </div>
                <div className="flex-1">
                  <p className="text-xs text-background/50 uppercase tracking-wider">Location</p>
                  <p className="text-background font-medium">{personalInfo.location}</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Footer */}
        <div className="mt-16 pt-8 border-t border-background/10 text-center space-y-2">
          <p className="text-background/40 text-sm">
            &copy; {new Date().getFullYear()} {personalInfo.name}. All rights reserved.
          </p>
          <p className="text-background/30 text-xs flex items-center justify-center gap-1.5">
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-primary/60"></span>
            Designed & built with AI assistance — demonstrating applied AI fluency in practice
          </p>
        </div>
      </div>
    </section>
  );
}
