/**
 * Design: Warm Professional - Human-Centered Minimalism
 * Vertical timeline with left-aligned rail and animated nodes
 */
import { timeline } from "@/lib/portfolio-data";
import { motion } from "framer-motion";
import { useInView } from "@/hooks/useInView";
import { Briefcase } from "lucide-react";

export default function TimelineSection() {
  const { ref, inView } = useInView({ threshold: 0.1 });

  return (
    <section id="timeline" className="py-20 lg:py-28" ref={ref}>
      <div className="container">
        {/* Section header */}
        <motion.div
          className="max-w-2xl mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <span className="text-sm font-medium text-primary uppercase tracking-wider">
            Journey
          </span>
          <h2 className="font-heading font-bold text-3xl sm:text-4xl lg:text-5xl text-foreground mt-3">
            Professional Timeline
          </h2>
        </motion.div>

        {/* Timeline */}
        <div className="relative">
          {/* Vertical line */}
          <div className="absolute left-4 lg:left-8 top-0 bottom-0 w-0.5 bg-border" />

          <div className="space-y-10 lg:space-y-12">
            {timeline.map((item, i) => (
              <motion.div
                key={item.id}
                className="relative pl-12 lg:pl-20"
                initial={{ opacity: 0, x: -20 }}
                animate={inView ? { opacity: 1, x: 0 } : {}}
                transition={{ delay: i * 0.15, duration: 0.5 }}
              >
                {/* Node */}
                <div
                  className={`absolute left-2 lg:left-6 top-1 w-5 h-5 rounded-full border-4 ${
                    item.isCurrent
                      ? "bg-primary border-primary/30 shadow-lg shadow-primary/20"
                      : "bg-card border-border"
                  }`}
                />

                {/* Card */}
                <div className="bg-card rounded-xl p-6 border border-border shadow-sm hover:shadow-md transition-shadow">
                  <div className="flex flex-wrap items-center gap-3 mb-3">
                    <span className="text-sm font-medium text-primary bg-primary/10 px-3 py-1 rounded-full">
                      {item.date}
                    </span>
                    {item.isCurrent && (
                      <span className="text-xs font-medium text-green-700 bg-green-50 px-2 py-0.5 rounded-full border border-green-200">
                        Current
                      </span>
                    )}
                  </div>

                  <h3 className="font-heading font-bold text-xl text-foreground flex items-center gap-2">
                    <Briefcase size={18} className="text-muted-foreground" />
                    {item.company}
                  </h3>

                  <p className="text-muted-foreground text-sm mt-1 mb-3">
                    {item.role}
                  </p>

                  <div className="flex flex-wrap gap-2">
                    {item.responsibilities.map((r) => (
                      <span
                        key={r}
                        className="px-2.5 py-1 text-xs font-medium rounded-md bg-muted text-muted-foreground"
                      >
                        {r}
                      </span>
                    ))}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
