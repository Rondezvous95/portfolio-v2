/**
 * Design: Warm Professional - Human-Centered Minimalism
 * Asymmetric hero with gradient mesh background, name, tagline, CTA, and certification badges
 * Profile photo is subtle — small circular avatar near the name, not a dominant element
 */
import { personalInfo } from "@/lib/portfolio-data";
import { motion } from "framer-motion";
import { ArrowDown, Linkedin, Mail } from "lucide-react";

const certificationBadges = [
  {
    name: "Google Project Management",
    image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663384870105/gslmbXHynuNpFYFu.png",
  },
  {
    name: "Google Data Analytics",
    image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663384870105/tlUbxzsTOdxBCklc.png",
  },

  {
    name: "Meta Certified Digital Marketing Associate",
    image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663384870105/uhltpPHZRGbOLuJg.png",
  },
  {
    name: "Salesforce Trailhead Adventurer",
    image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663384870105/rLDZKVWEykBsSaUZ.png",
  },
];

export default function HeroSection() {
  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center overflow-hidden"
    >
      {/* Background gradient mesh */}
      <div
        className="absolute inset-0 bg-cover bg-center opacity-50"
        style={{
          backgroundImage: `url(https://d2xsxph8kpxj0f.cloudfront.net/310519663384870105/K2kiBXTGU6QriZuxEk6rc3/hero-bg-5QNsSDUuMvugsHwyLcHwar.webp)`,
        }}
      />
      {/* Overlay for text readability */}
      <div className="absolute inset-0 bg-gradient-to-br from-background/85 via-background/70 to-background/40" />

      <div className="container relative z-10 pt-24 pb-16">
        <div className="max-w-3xl">
          {/* Text content */}
          <motion.div
            className="space-y-6"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            {/* Specialty pills */}
            <motion.div
              className="flex flex-wrap gap-2"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3, duration: 0.6 }}
            >
              {personalInfo.specialties.map((s) => (
                <span
                  key={s}
                  className="px-3 py-1 text-xs font-medium rounded-full bg-primary/10 text-primary border border-primary/20"
                >
                  {s}
                </span>
              ))}
            </motion.div>

            {/* Name with small avatar inline */}
            <div className="flex items-center gap-5">
              <motion.div
                className="w-16 h-16 sm:w-20 sm:h-20 rounded-full overflow-hidden ring-2 ring-primary/20 ring-offset-2 ring-offset-background shadow-md shrink-0"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.2, duration: 0.6 }}
              >
                <img
                  src="https://files.manuscdn.com/user_upload_by_module/session_file/310519663384870105/HcEsmukvQKHjhmuf.jpg"
                  alt="Ron Liang"
                  className="w-full h-full object-cover object-top"
                />
              </motion.div>
              <h1 className="font-heading font-bold text-4xl sm:text-5xl lg:text-6xl xl:text-7xl text-foreground leading-tight">
                {personalInfo.name}
              </h1>
            </div>

            <p className="text-lg sm:text-xl text-muted-foreground max-w-xl leading-relaxed">
              {personalInfo.title}
            </p>

            <blockquote className="border-l-4 border-primary/40 pl-4 italic text-muted-foreground text-base sm:text-lg max-w-lg">
              "{personalInfo.tagline}"
            </blockquote>

            {/* CTA buttons */}
            <motion.div
              className="flex flex-wrap gap-4 pt-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5, duration: 0.6 }}
            >
              <a
                href="#contact"
                className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground font-medium rounded-full hover:bg-primary/90 transition-all hover:shadow-lg hover:shadow-primary/20"
              >
                <Mail size={18} />
                Get in Touch
              </a>
              <a
                href={personalInfo.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3 border border-border bg-card/80 text-foreground font-medium rounded-full hover:bg-accent transition-all"
              >
                <Linkedin size={18} />
                LinkedIn
              </a>
            </motion.div>

            {/* Certification badges */}
            <motion.div
              className="pt-8"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.7, duration: 0.8 }}
            >
              <p className="text-xs uppercase tracking-wider text-muted-foreground/70 font-medium mb-3">
                Certified By
              </p>
                <div className="flex flex-wrap items-center gap-4">
                {certificationBadges.map((badge) => (
                  <div
                    key={badge.name}
                    className="group relative"
                  >
                    <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-lg bg-white/80 border border-border/50 p-2 shadow-sm hover:shadow-md hover:scale-105 transition-all duration-300">
                      <img
                        src={badge.image}
                        alt={badge.name}
                        className="w-full h-full object-contain"
                      />
                    </div>
                    {/* Tooltip on hover */}
                    <div className="absolute -top-10 left-1/2 -translate-x-1/2 px-2 py-1 bg-foreground text-background text-[10px] font-medium rounded whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                      {badge.name}
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </motion.div>
        </div>

        {/* Scroll indicator */}
        <motion.div
          className="absolute bottom-8 left-1/2 -translate-x-1/2"
          animate={{ y: [0, 8, 0] }}
          transition={{ repeat: Infinity, duration: 2 }}
        >
          <a href="#about" className="text-muted-foreground hover:text-primary transition-colors">
            <ArrowDown size={24} />
          </a>
        </motion.div>
      </div>
    </section>
  );
}
