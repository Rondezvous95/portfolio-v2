/**
 * Design: Warm Professional - Human-Centered Minimalism
 * Education, Certifications, Awards & Volunteer Experience section
 */
import { education, certifications, awards, volunteerExperience } from "@/lib/portfolio-data";
import { motion } from "framer-motion";
import { useInView } from "@/hooks/useInView";
import { GraduationCap, Award, BadgeCheck, Trophy, Heart } from "lucide-react";

export default function EducationSection() {
  const { ref, inView } = useInView({ threshold: 0.1 });

  return (
    <section id="education" className="py-20 lg:py-28 bg-muted/30" ref={ref}>
      <div className="container">
        {/* Section header */}
        <motion.div
          className="text-center max-w-2xl mx-auto mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <span className="text-sm font-medium text-primary uppercase tracking-wider">
            Credentials
          </span>
          <h2 className="font-heading font-bold text-3xl sm:text-4xl lg:text-5xl text-foreground mt-3">
            Education & Credentials
          </h2>
        </motion.div>

        {/* Top row: Education + Certifications */}
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 mb-8 lg:mb-12">
          {/* Education */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.1, duration: 0.6 }}
          >
            <div className="bg-card rounded-2xl p-6 lg:p-8 border border-border shadow-sm h-full">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <GraduationCap className="text-primary" size={24} />
                </div>
                <h3 className="font-heading font-semibold text-xl text-foreground">
                  Education
                </h3>
              </div>

              <div className="space-y-5">
                {education.map((edu) => (
                  <div key={edu.institution} className="space-y-2">
                    <h4 className="font-heading font-bold text-lg text-foreground">
                      {edu.degree}
                    </h4>
                    <p className="text-muted-foreground text-base">
                      {edu.institution}
                    </p>
                    <div className="flex flex-wrap items-center gap-3 pt-2">
                      <span className="px-3 py-1 text-xs font-medium rounded-full bg-primary/10 text-primary border border-primary/20">
                        {edu.years}
                      </span>
                      {edu.honours && (
                        <span className="px-3 py-1 text-xs font-medium rounded-full bg-amber-50 text-amber-700 border border-amber-200">
                          {edu.honours}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Certifications */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.2, duration: 0.6 }}
          >
            <div className="bg-card rounded-2xl p-6 lg:p-8 border border-border shadow-sm h-full">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <Award className="text-primary" size={24} />
                </div>
                <h3 className="font-heading font-semibold text-xl text-foreground">
                  Certifications
                </h3>
              </div>

              <div className="space-y-3">
                {certifications.map((cert) => (
                  <div
                    key={cert.name}
                    className="flex items-start gap-3 p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
                  >
                    <BadgeCheck className="text-primary mt-0.5 shrink-0" size={18} />
                    <div>
                      <p className="text-sm font-medium text-foreground">
                        {cert.name}
                      </p>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {cert.issuer}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>

        {/* Bottom row: Awards + Volunteer */}
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
          {/* Awards */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.3, duration: 0.6 }}
          >
            <div className="bg-card rounded-2xl p-6 lg:p-8 border border-border shadow-sm h-full">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 rounded-full bg-amber-50 flex items-center justify-center">
                  <Trophy className="text-amber-600" size={24} />
                </div>
                <h3 className="font-heading font-semibold text-xl text-foreground">
                  Awards & Recognition
                </h3>
              </div>

              <div className="space-y-3">
                {awards.map((award) => (
                  <div
                    key={award.name}
                    className="flex items-start gap-3 p-3 rounded-lg bg-amber-50/50 hover:bg-amber-50 transition-colors"
                  >
                    <Trophy className="text-amber-600 mt-0.5 shrink-0" size={16} />
                    <div>
                      <p className="text-sm font-medium text-foreground">
                        {award.name}
                      </p>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {award.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Volunteer Experience */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.4, duration: 0.6 }}
          >
            <div className="bg-card rounded-2xl p-6 lg:p-8 border border-border shadow-sm h-full">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 rounded-full bg-rose-50 flex items-center justify-center">
                  <Heart className="text-rose-500" size={24} />
                </div>
                <h3 className="font-heading font-semibold text-xl text-foreground">
                  Volunteer Experience
                </h3>
              </div>

              <div className="space-y-4">
                {volunteerExperience.map((vol) => (
                  <div
                    key={vol.role}
                    className="p-3 rounded-lg bg-rose-50/50 hover:bg-rose-50 transition-colors"
                  >
                    <p className="text-sm font-medium text-foreground">
                      {vol.role}
                    </p>
                    <p className="text-xs font-medium text-muted-foreground mt-0.5">
                      {vol.organization}
                      {vol.period && ` · ${vol.period}`}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1.5 leading-relaxed">
                      {vol.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
