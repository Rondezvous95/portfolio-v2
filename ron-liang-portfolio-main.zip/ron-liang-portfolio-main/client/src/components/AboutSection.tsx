/**
 * Design: Warm Professional - Human-Centered Minimalism
 * Executive summary with animated metrics and clean typography
 */
import { executiveSummary, skills } from "@/lib/portfolio-data";
import { motion } from "framer-motion";
import { useInView } from "@/hooks/useInView";
import { BookOpen, Users, Globe, BarChart3, TrendingUp } from "lucide-react";

const highlights = [
  { icon: BookOpen, value: "5+", label: "Years Experience" },
  { icon: Users, value: "200+", label: "Analysts Trained" },
  { icon: Globe, value: "4", label: "Countries" },
  { icon: BarChart3, value: "73%", label: "Faster Onboarding" },
  { icon: TrendingUp, value: "100%", label: "Pass Rate" },
];

const categoryColors: Record<string, string> = {
  Training: "bg-primary/10 text-primary border-primary/20",
  Operations: "bg-blue-50 text-blue-700 border-blue-200",
  Enablement: "bg-amber-50 text-amber-700 border-amber-200",
  Data: "bg-violet-50 text-violet-700 border-violet-200",
};

export default function AboutSection() {
  const { ref, inView } = useInView({ threshold: 0.2 });

  return (
    <section id="about" className="py-20 lg:py-28" ref={ref}>
      <div className="container">
        {/* Section header */}
        <motion.div
          className="max-w-3xl mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <span className="text-sm font-medium text-primary uppercase tracking-wider">
            About Me
          </span>
          <h2 className="font-heading font-bold text-3xl sm:text-4xl lg:text-5xl text-foreground mt-3 mb-6">
            {executiveSummary.headline}
          </h2>
          <div className="space-y-4">
            {executiveSummary.paragraphs.map((p, i) => (
              <p key={i} className="text-muted-foreground text-base sm:text-lg leading-relaxed">
                {p}
              </p>
            ))}
          </div>
        </motion.div>

        {/* Metrics grid */}
        <motion.div
          className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 lg:gap-5 mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.2, duration: 0.6 }}
        >
          {highlights.map((item, i) => (
            <div
              key={i}
              className="bg-card rounded-xl p-5 border border-border shadow-sm hover:shadow-md transition-shadow"
            >
              <item.icon className="text-primary mb-3" size={22} />
              <div className="font-heading font-bold text-2xl lg:text-3xl text-foreground">
                {item.value}
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                {item.label}
              </div>
            </div>
          ))}
        </motion.div>

        {/* Skills */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.4, duration: 0.6 }}
        >
          <h3 className="font-heading font-semibold text-xl text-foreground mb-4">
            Core Competencies
          </h3>
          <div className="flex flex-wrap gap-2">
            {skills.map((skill) => (
              <span
                key={skill.name}
                className={`px-3 py-1.5 text-sm font-medium rounded-full border ${
                  categoryColors[skill.category] || "bg-muted text-muted-foreground border-border"
                }`}
              >
                {skill.name}
              </span>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
