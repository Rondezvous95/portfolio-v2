/**
 * Design: Warm Professional - Human-Centered Minimalism
 * Certifications section with badge images and short descriptions
 */
import React from "react";
import { motion } from "framer-motion";
import { useInView } from "@/hooks/useInView";

const certifications = [
  {
    name: "Google Project Management Certificate",
    issuer: "Google via Coursera",
    image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663384870105/gslmbXHynuNpFYFu.png",
    description:
      "Comprehensive training in project initiation, planning, execution, and closing. Covers Agile methodologies, stakeholder management, risk assessment, and using tools like Asana and spreadsheets for project tracking.",
  },
  {
    name: "Google Data Analytics Certificate",
    issuer: "Google via Coursera",
    image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663384870105/tlUbxzsTOdxBCklc.png",
    description:
      "Foundational skills in data cleaning, analysis, and visualization using spreadsheets, SQL, Tableau, and R. Covers the full data analysis process from asking the right questions to presenting actionable insights.",
  },

  {
    name: "Meta Certified Digital Marketing Associate",
    issuer: "Meta (formerly Facebook)",
    image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663384870105/uhltpPHZRGbOLuJg.png",
    description:
      "Validates competency in digital advertising fundamentals across Meta platforms. Covers campaign creation, audience targeting, ad placement optimization, budget management, and performance measurement using Meta Business Suite.",
  },
  {
    name: "Salesforce Trailhead Adventurer",
    issuer: "Salesforce",
    image: "https://files.manuscdn.com/user_upload_by_module/session_file/310519663384870105/rLDZKVWEykBsSaUZ.png",
    description:
      "Demonstrates proficiency in Salesforce platform fundamentals through hands-on learning modules. Covers CRM concepts, data management, reporting, and platform navigation — building a foundation for customer relationship management.",
  },
];

export default function CertificationsSection() {
  const { ref, inView } = useInView({ threshold: 0.1 });

  return (
    <section id="certifications" className="py-20 bg-secondary/30" ref={ref as React.RefObject<HTMLElement>}>
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="mb-12"
        >
          <p className="text-sm uppercase tracking-wider text-primary font-medium mb-2">
            Professional Development
          </p>
          <h2 className="font-heading text-3xl sm:text-4xl font-bold text-foreground">
            Certifications
          </h2>
        </motion.div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {certifications.map((cert, index) => (
            <motion.div
              key={cert.name}
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-card border border-border/60 rounded-xl p-6 hover:shadow-lg hover:border-primary/20 transition-all duration-300 group"
            >
              <div className="flex items-start gap-4 mb-4">
                <div className="w-16 h-16 shrink-0 rounded-lg bg-white border border-border/40 p-2 group-hover:scale-105 transition-transform duration-300">
                  <img
                    src={cert.image}
                    alt={cert.name}
                    className="w-full h-full object-contain"
                  />
                </div>
                <div>
                  <h3 className="font-heading font-semibold text-foreground text-sm leading-tight">
                    {cert.name}
                  </h3>
                  <p className="text-xs text-muted-foreground mt-1">
                    {cert.issuer}
                  </p>
                </div>
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {cert.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
