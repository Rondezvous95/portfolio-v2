/**
 * ============================================================
 * PORTFOLIO DATA - EASY TO EDIT
 * ============================================================
 * All portfolio content is centralized here.
 * To update the website, simply edit the values below.
 * No coding knowledge required - just change the text!
 * ============================================================
 */

export const personalInfo = {
  name: "Ron Liang",
  title: "Learning & Development & Enablement Professional",
  tagline: "Every training I deliver aims to empower someone to do their best work — better than yesterday.",
  specialties: ["Training", "Operations", "Enablement", "Data-Driven Learning"],
  phone: "+65 83222892",
  email: "liangron95@gmail.com",
  linkedin: "https://www.linkedin.com/in/ronliang/",
  location: "Singapore",
};

export const executiveSummary = {
  headline: "Empowering Teams Through Scalable Learning",
  paragraphs: [
    "Learning & Enablement professional with 5+ years of progressive experience at Accenture within Meta's support operations under a managed service delivery model.",
    "Promoted from Analyst to Product Trainer within 6 months, subsequently taking on concurrent Operations Lead responsibilities. Proven record of redesigning onboarding programmes to cut time-to-productivity by 73%, achieving a 100% assessment pass rate across 200+ analysts, and sustaining client CSAT scores above benchmark.",
    "Combines deep instructional design expertise with operational rigour across SLA governance, workforce planning, and executive client reporting — consistently delivering under commercial and contractual pressures inherent to client-facing service delivery.",
  ],
};

export const achievements = [
  {
    id: 1,
    title: "International Launch",
    subtitle: "Bangkok, Q2 2025 – Ongoing",
    description: "Led the setup of a new product support office in Bangkok, training 22 new analysts from the ground up.",
    details: [
      "22 new analysts onboarded",
      "6 days of process ILT",
      "10 days of product ILT",
      "10 days of nesting",
      "10 days of early remap",
    ],
    metric: "22",
    metricLabel: "New Analysts Trained",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663384870105/K2kiBXTGU6QriZuxEk6rc3/achievement-international-DpuWbAT6Bdn8MfsCV4SDid.webp",
  },
  {
    id: 2,
    title: "Onboarding Redesign",
    subtitle: "73% Faster Time-to-Productivity",
    description: "Led full end-to-end curriculum redesigns — covering instructional design, content creation, training methodology, and execution — reducing onboarding from 1 month to 8 days.",
    details: [
      "1 month → 8 days onboarding",
      "100% assessment pass rate",
      "20 batches across 4 countries",
      "98% throughput rate",
    ],
    metric: "73%",
    metricLabel: "Faster Onboarding",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663384870105/K2kiBXTGU6QriZuxEk6rc3/achievement-onboarding-v2-maFZacf3bTuS8NpQbut37P.webp",
  },
  {
    id: 3,
    title: "APAC Training Scale",
    subtitle: "200+ Analysts Across 4 Countries",
    description: "Trained 200+ analysts across 20 batches in Singapore, Dublin, Hyderabad, and Bangkok, achieving 98% throughput and 100% assessment pass rate consistently across all cohorts.",
    details: [
      "200+ analysts trained",
      "Singapore, Dublin, Hyderabad, Bangkok",
      "100% pass rate all cohorts",
      "Blended 8-day programme",
    ],
    metric: "200+",
    metricLabel: "Analysts Trained Globally",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663384870105/K2kiBXTGU6QriZuxEk6rc3/achievement-scale-v2-EZtHUfhUqqNS6WdtcA7bwd.webp",
  },
];

export const timeline = [
  {
    id: 1,
    date: "Jan 2020",
    company: "Maxco Food Industries Pte Ltd",
    role: "Business Admin & Training Coordinator (Part-time / Freelance)",
    responsibilities: [
      "CPF, Payroll & Compliance",
      "Digital Marketing (Hootsuite, Sendinblue)",
      "Vendor Licensing & SFA Documentation",
    ],
  },
  {
    id: 2,
    date: "Sep 2020",
    company: "Doxa Holdings International",
    role: "Onboarding & Client Training Associate",
    responsibilities: [
      "Enterprise Onboarding (50+ clients incl. DBS, Tiong Seng)",
      "Enablement Content (4 onboarding videos)",
      "Cross-functional Partnership",
    ],
  },
  {
    id: 3,
    date: "May 2021",
    company: "Accenture @ Meta",
    role: "Customer Support Analyst",
    responsibilities: [
      "Customer Support Cases",
      "Content Moderation",
      "Product Knowledge Development",
    ],
  },
  {
    id: 4,
    date: "Dec 2021",
    company: "Accenture @ Meta",
    role: "Product Trainer (Promoted within 6 months)",
    responsibilities: [
      "Onboarding Programme Redesign",
      "Curriculum Design & ILT Delivery",
      "CSAT Coaching & Performance",
      "Meta Learning Stakeholder Partnership",
    ],
    isCurrent: true,
  },
  {
    id: 5,
    date: "Oct 2023",
    company: "Accenture @ Meta",
    role: "Operations Team Lead (Concurrent)",
    responsibilities: [
      "15-Analyst Team Operations",
      "SLA & Workforce Planning",
      "Client Governance (WBR/MBR/QBR)",
      "Change Management (D2C Chat rollout)",
    ],
    isCurrent: true,
  },
];

export const projects = [
  {
    id: 1,
    title: "Meta x Accenture Project",
    description: "Large-scale product support and training project serving Meta's advertising platform users across APAC with regional scope spanning Singapore, Thailand, Ireland, and India.",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663384870105/K2kiBXTGU6QriZuxEk6rc3/project-meta-accenture-5aXSDEkf3VYoPdoN8GqNL2.webp",
  },
  {
    id: 2,
    title: "SGP Training Team",
    description: "Led the Singapore-based training team responsible for onboarding and upskilling analysts across 20 batches with 98% throughput.",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663384870105/K2kiBXTGU6QriZuxEk6rc3/project-sgp-team-c6Pexc5axGacxttm6itoay.webp",
  },
  {
    id: 3,
    title: "BKK Office Ramp Up",
    description: "Spearheaded the Bangkok office setup, recruiting and training 22 new team members including Team Leads, QA, and SMEs from scratch.",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663384870105/K2kiBXTGU6QriZuxEk6rc3/project-bkk-rampup-aXXJAukdDhKRTipDDRn7vM.webp",
  },
];

export const testimonials = [
  {
    id: 1,
    quote: "I had the pleasure of working with Ron as both my trainer and team lead on a technical product support project, and I can honestly say he's one of the best colleagues I've ever worked with. Ron always takes his work seriously and puts a lot of effort into making sure everything he does is top-notch. When it comes to training, Ron is incredibly detailed. His sessions are clear and well-structured, and his training materials make even complicated topics easy to understand. He genuinely cares about helping others learn and succeed. As a team lead, Ron led by example — he was always there to help us with any issues, regularly checked in to see how we were doing, and gave us practical advice to help us improve. Ron is always looking for ways to make things better. One of his projects — a detailed process flow that mapped out all the scenarios analysts face — was so impactful that he received the Golden Spotlight Award. I highly recommend him to any team looking for someone who truly cares about people and quality.",
    author: "Hanif Roslan",
    role: "Colleague & Direct Report",
    type: "linkedin",
  },
  {
    id: 2,
    quote: "Ron is a dedicated and exceptionally helpful colleague. His commitment extends beyond his formal responsibilities, consistently exceeding expectations. His patience in guiding new staff, coupled with his innovative approach (e.g., creating a process flowchart that garnered client commendation and the highest project accolades), makes him an invaluable asset to any team.",
    author: "Michael Mak",
    role: "Colleague at Accenture",
    type: "linkedin",
  },
  {
    id: 3,
    quote: "Congratulations for being recognized as Rockstar for May and for all the hard work you have done. You deliver exemplary work for our clients and our customers. Being the Champion of Change, CSAT Champ and receiving Client Moments, is something you should be proud of.",
    author: "Emma A. Atienza",
    role: "Performance Recognition",
    type: "internal",
  },
  {
    id: 4,
    quote: "I wanted to express my sincere appreciation for your outstanding support in our recent Outbound Calling Training for the TSA program. As our Trainer and SME, you went above and beyond what was expected. Your willingness to help and support our team has been instrumental in creating a positive and productive learning environment.",
    author: "Levely Esguerra",
    role: "Vendor Manager, GSO Vendor Operations",
    type: "client",
  },
  {
    id: 5,
    quote: "Ron's really good at process map. I think he created something when we were at ACN SG visit the last time round, explaining FP FN etc.",
    author: "Joanne Chan",
    role: "Colleague",
    type: "peer",
  },
];

export const skills = [
  { name: "Training Delivery & Facilitation", category: "Training" },
  { name: "Onboarding Programme Design", category: "Training" },
  { name: "Instructional Design", category: "Training" },
  { name: "Adult Learning Principles", category: "Training" },
  { name: "Curriculum Development", category: "Training" },
  { name: "LMS Management", category: "Training" },
  { name: "Enablement Content Creation", category: "Enablement" },
  { name: "Coaching & Feedback", category: "Enablement" },
  { name: "Change Enablement", category: "Enablement" },
  { name: "Cross-functional Collaboration", category: "Enablement" },
  { name: "SLA & Queue Management", category: "Operations" },
  { name: "Workforce Planning", category: "Operations" },
  { name: "Performance Management", category: "Operations" },
  { name: "Client Governance (WBR/MBR/QBR)", category: "Operations" },
  { name: "Data-Driven Forecasting", category: "Data" },
  { name: "Capacity Management", category: "Data" },
  { name: "Performance Analytics", category: "Data" },
];

export const education = [
  {
    degree: "Bachelor of Business Management",
    institution: "Singapore Management University",
    years: "2016 – 2020",
    honours: "High Merit",
  },
  {
    degree: "GCE \"A\" Levels Certificate",
    institution: "Tampines Junior College",
    years: "2012 – 2013",
  },
];

export const certifications = [
  { name: "Google Data Analytics Certificate", issuer: "Google" },
  { name: "Google Project Management Certificate", issuer: "Google" },
  { name: "Meta Certified Digital Marketing Associate", issuer: "Meta" },
  { name: "Accenture Reinvention with Agentic AI", issuer: "Accenture (In-house)" },
];

export const awards = [
  { name: "Golden Spotlight Award", description: "Received for creating a detailed process flow mapping all analyst scenarios, connecting team work to management expectations" },
  { name: "Quality Superstar Award", description: "Highest accuracy score among the team during analyst tenure" },
  { name: "Rockstar of the Month", description: "Recognized as Champion of Change and CSAT Champ" },
];

export const volunteerExperience = [
  {
    role: "Meals Delivery Volunteer",
    organization: "Dorcas Home Care Limited",
    description: "Delivered cooked meals to approximately 50 participants daily under the welfare program of Singapore, supporting those with mobility and/or financial difficulties.",
  },
  {
    role: "Logistics Manager",
    organization: "Youth Expedition Programme — Cambodia",
    period: "Jun 2011 – Dec 2011",
    description: "Led logistics for an overseas community service program in Cambodia: renovated classrooms, installed bio-friendly water filters, and built a primary school classroom from scratch.",
  },
];

export const experienceDetails = [
  {
    id: 1,
    company: "Accenture @ Meta",
    location: "Singapore (regional scope: Thailand, Ireland, India)",
    role: "Product Trainer",
    period: "Dec 2021 – Present",
    promoted: true,
    highlights: [
      "Led full end-to-end curriculum redesigns reducing onboarding from 1 month to 8 days (73% faster time-to-productivity)",
      "Trained 200+ analysts across 20 batches in Singapore, Dublin, Hyderabad, and Bangkok with 98% throughput and 100% pass rate",
      "Designed a blended 8-day onboarding journey comprising process ILTs and product ILTs, followed by nesting and ramp up phases",
      "Sustained team CSAT at 55% against a 50% client benchmark through weekly coaching and soft skills development",
      "Partnered with Meta Learning stakeholders to continuously revise content in response to product and policy changes",
    ],
  },
  {
    id: 2,
    company: "Accenture @ Meta",
    location: "Singapore",
    role: "Operations Team Lead (Concurrent)",
    period: "Oct 2023 – Aug 2024",
    promoted: false,
    highlights: [
      "Managed day-to-day operations for a 15-analyst team covering queue management, SLA tracking, and workforce planning",
      "Used data-driven QA reviews to stabilise team performance; led targeted 1-on-1 coaching for bottom-quartile analysts",
      "Represented Training and Operations in WBR, MBR, and QBR sessions with Meta presenting readiness metrics and remediation plans",
      "Led training enablement for a 9-to-5 product consolidation and D2C Chat model rollout enabling 120 analysts without business disruption",
    ],
  },
  {
    id: 3,
    company: "Accenture @ Meta",
    location: "Singapore",
    role: "Customer Support Analyst",
    period: "May 2021 – Nov 2021",
    promoted: false,
    highlights: [
      "Reviewed and resolved customer support cases and content moderation queues",
      "Developed deep product knowledge that underpinned subsequent promotion to Product Trainer within 6 months",
    ],
  },
  {
    id: 4,
    company: "Doxa Holdings International",
    location: "Singapore",
    role: "Onboarding & Client Training Associate",
    period: "Sep 2020 – Apr 2021",
    promoted: false,
    highlights: [
      "Led onboarding for 50+ enterprise clients and vendor partners including DBS and Tiong Seng",
      "Produced 4 onboarding videos and supporting materials that measurably reduced inbound support volume",
      "Collaborated with product and customer success teams to localise training content",
    ],
  },
  {
    id: 5,
    company: "Maxco Food Industries Pte Ltd",
    location: "Singapore",
    role: "Business Admin & Training Coordinator",
    period: "Jan 2020 – Jan 2025 (Part-time / Freelance)",
    promoted: false,
    highlights: [
      "Managed CPF, payroll, and compliance data across HR and finance workflows",
      "Administered digital marketing operations via Hootsuite and Sendinblue",
      "Oversaw vendor licensing and regulatory documentation with Singapore Food Agency (SFA)",
    ],
  },
];
